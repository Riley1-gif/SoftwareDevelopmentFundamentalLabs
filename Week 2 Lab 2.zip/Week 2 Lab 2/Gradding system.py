score = int(input("Enter your score: "))

if score >= 90: 
    print("Grade: A")
elif score >= 80:
    print("Grade: B")
elif score >= 70:
    print("Grade: C")
elif score > 100:
    print("Thats not a valid score")
elif score <= 0:
    print("Thats not a valid score")
else: 
    print("Grade: F")


    